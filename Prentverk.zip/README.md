This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Vefsíða Prentverk á Selfossi

### NPM run startup

Kveikir á síðunni og opnar á næsta lausa porti eða 2666. 
Mun öskra á þig hvaða port er í notkun í command tool.

### Tól sem að voru notuð:
* React
* Styled-Components
* GSAP
* Express
* Nodemailer
* Adobe XD

### Lýsing
Bjó fyrst til þessa síðu: [Prentverk](http://prentverk.biggaferdir.is/).

Endaði á því að vera ekki nógu sáttur með hana og breytti því yfir í þessa
síðu sem að er hér. Einföld síða sem að ég notaði einnig til að læra á GSAP.

