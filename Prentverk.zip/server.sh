echo "Serving yourAppName!"
serve -s build