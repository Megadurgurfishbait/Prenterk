module.exports = {
    pass: "Gunnariprentverk"
}